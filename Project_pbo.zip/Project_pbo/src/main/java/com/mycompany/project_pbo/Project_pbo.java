/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project_pbo;

/**
 *
 * @author root
 */
public class Project_pbo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
